#!/system/bin/sh
# hkmc.track-button-swap — apply (or restore) the seek-key swap, reload the
# keymap, exit. Runs at every boot and right after install.
APP=${TBS_APP:-/data/nemesis/apps/hkmc.track-button-swap}
. "$APP/scripts/common.sh"

seed_config
LOCK=$WORK/lock
if ! mkdir "$LOCK" 2>/dev/null; then
    read _p < "$LOCK/pid" 2>/dev/null
    if [ -n "$_p" ] && [ -d "/proc/$_p" ]; then
        log "swap: another run (pid $_p) is active; exiting"
        exit 0
    fi
fi
echo $$ > "$LOCK/pid"
trap 'rm -rf "$LOCK"' EXIT

log "---- swap start (pid $$)"
wait_boot
sleep "${TBS_SETTLE:-8}"   # let InputManager finish enumerating devices

if [ "$(cfg enabled 1)" != 1 ]; then
    log "enabled=0: restoring stock mapping"
    restore_all
    log "---- swap end (disabled)"
    exit 0
fi

if do_apply; then
    reload_for_kl "$KL" || log "keymap not reloaded live; it takes effect after a reboot"
    log "---- swap end (active: $SA<->$SB in $KL)"
else
    # Detection can fail transiently (device not enumerated yet). Never
    # revert a working swap for that; just make sure it is live.
    if [ -f "$STATE_DIR/.applied" ]; then
        read _line < "$STATE_DIR/.applied"
        KL=${_line#kl=}
        log "keeping previous swap on $KL"
        reload_for_kl "$KL" || log "keymap not reloaded live; it takes effect after a reboot"
    fi
    log "---- swap end (NOT applied this run)"
fi
exit 0
