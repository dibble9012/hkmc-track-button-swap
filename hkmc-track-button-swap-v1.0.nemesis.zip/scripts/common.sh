#!/system/bin/sh
# hkmc.track-button-swap — shared helpers.
#
# Strategy: swap the scancode->keycode mapping for the two steering-wheel
# seek scancodes inside the keylayout (.kl) file of the input device that
# delivers them. Android then only ever produces the swapped keycode, so the
# stock action can never fire alongside the new one.
#
# Toolbox-safe: no sed/tr/printf/head/tail/awk. Only echo/cat/grep/read/case,
# cp/mv/rm/ln/mknod/chmod/chown/ls/md5, getprop/dumpsys.

export PATH=${TBS_TEST_PATH:+$TBS_TEST_PATH:}/data/nemesis/bin:/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin${TBS_TEST_PATH:+:/usr/bin:/bin}
export LD_LIBRARY_PATH=/vendor/lib:/system/lib

PKG_ID=hkmc.track-button-swap
NEM=${TBS_NEMESIS_ROOT:-/data/nemesis}
STATE_DIR=$NEM/state/$PKG_ID
BACKUP_DIR=$NEM/backup/$PKG_ID
LOG_DIR=$NEM/logs/$PKG_ID
LOG=$LOG_DIR/apply.log
# not /data/local/tmp: it is shell-owned and NEMESIS root lacks DAC override there
WORK=${TBS_WORK:-$NEM/work/$PKG_ID}
SYS_PREFIX=${TBS_SYS_PREFIX:-/system/}
TMP_NODE=${TBS_TMP_NODE:-/dev/.hkmc.track-button-swap_node}
SYSCLASS=${TBS_SYSCLASS:-/sys/class/input}
INPUT_DIR=${TBS_INPUT_DIR:-/dev/input}

ts() {
    date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || date
}

log() {
    echo "$*"
    mkdir -p "$LOG_DIR" 2>/dev/null
    echo "$(ts) $*" >> "$LOG" 2>/dev/null
}

have() {
    command -v "$1" >/dev/null 2>&1 && return 0
    # mksh without `command -v`: probe the usual dirs
    [ -x "/system/bin/$1" ] || [ -x "/system/xbin/$1" ] || [ -x "/sbin/$1" ]
}

# ---------- config (one value per file in the state dir) ----------

cfg() {
    local _v=""
    if [ -f "$STATE_DIR/$1" ]; then
        read _v < "$STATE_DIR/$1" 2>/dev/null
    fi
    set -f
    set -- $_v "$2"
    set +f
    # first word of the file, or the default if the file was empty
    if [ -n "$_v" ]; then echo "$1"; else echo "$2"; fi
}

seed_one() {
    [ -f "$STATE_DIR/$1" ] || echo "$2" > "$STATE_DIR/$1"
}

seed_config() {
    mkdir -p "$STATE_DIR" "$LOG_DIR" "$WORK" 2>/dev/null
    seed_one enabled 1           # 0 = restore stock mapping and stay idle
    seed_one key_a CHANNEL_UP    # the two keycode labels to exchange (EV6: wheel seek = CHANNEL_UP/DOWN)
    seed_one key_b CHANNEL_DOWN
    seed_one scan_a 34           # stock scancode of key_a (EV6 wheel UP); auto = the only one
    seed_one scan_b 35           # stock scancode of key_b (EV6 wheel DOWN)
    seed_one kl_file auto        # force a keylayout path, e.g. /system/usr/keylayout/foo.kl
    seed_one reload 1            # 1 = reopen the input node so the swap is live without reboot
    seed_one force 0             # 1 = apply even if another process reads the raw input node
    seed_one probe_seconds 45
}

# ---------- small utils ----------

file_md5() {
    local _line
    _line=$(md5 "$1" 2>/dev/null) || return 1
    set -- $_line
    [ -n "$1" ] || return 1
    echo "$1"
}

# /system/usr/keylayout/a.kl -> _system_usr_keylayout_a.kl
flat() {
    local _s="$1" _o="" _c
    while [ -n "$_s" ]; do
        _c=${_s%"${_s#?}"}
        _s=${_s#?}
        case "$_c" in
            [A-Za-z0-9._-]) _o="$_o$_c" ;;
            *) _o="${_o}_" ;;
        esac
    done
    echo "$_o"
}

count_words() {
    set -f
    set -- $1
    set +f
    echo $#
}

sys_rw() {
    [ "$SYS_PREFIX" = /system/ ] || return 0     # test harness
    /system/xbin/nemesis remount rw >/dev/null 2>&1 && return 0
    mount -o remount,rw /system 2>/dev/null && return 0
    return 1
}

sys_ro() {
    [ "$SYS_PREFIX" = /system/ ] || return 0
    /system/xbin/nemesis remount ro >/dev/null 2>&1 || mount -o remount,ro /system 2>/dev/null
    return 0
}

wait_boot() {
    local _i=0
    while [ "$(getprop sys.boot_completed 2>/dev/null)" != 1 ]; do
        _i=$((_i + 1))
        [ $_i -gt 180 ] && { log "boot_completed never reached; continuing"; return 0; }
        sleep 1
    done
}

# ---------- input devices (from `dumpsys input`, Event Hub section) ----------
# Writes  node|kl|name  lines to $WORK/devices.txt

_dev_emit() {
    if [ -n "$_node" ] && [ -n "$_kl" ]; then
        echo "$_node|$_kl|$_name" >> "$WORK/devices.txt"
    fi
}

list_devices() {
    local _line _hub=0 _name="" _node="" _kl=""
    mkdir -p "$WORK"
    : > "$WORK/devices.txt"
    dumpsys input > "$WORK/dumpsys_input.txt" 2>/dev/null
    while IFS= read -r _line || [ -n "$_line" ]; do
        case "$_line" in
            *"Event Hub State:"*) _hub=1; continue ;;
            *"Input Reader State:"*) break ;;
        esac
        [ $_hub = 1 ] || continue
        set -f
        set -- $_line
        set +f
        case "$1" in
            [0-9]*:|-[0-9]*:)
                _dev_emit
                _name=${_line#*: }; _node=""; _kl="" ;;
            Path:) _node=$2 ;;
            KeyLayoutFile:) _kl=$2 ;;
        esac
    done < "$WORK/dumpsys_input.txt"
    _dev_emit
}

# ---------- keylayout parsing ----------

# scancodes in file $1 that map to label $2 (plain "key <scan> <LABEL>" lines)
scans_for() {
    local _f="$1" _line _out=""
    while IFS= read -r _line || [ -n "$_line" ]; do
        set -f
        set -- $_line
        set +f
        [ "$1" = key ] || continue
        [ "$2" = usage ] && continue
        [ "$3" = "$LAB" ] && _out="$_out $2"
    done < "$_f"
    echo $_out
}

# label for scancode $2 in file $1
label_of() {
    local _f="$1" _line
    while IFS= read -r _line || [ -n "$_line" ]; do
        set -f
        set -- $_line
        set +f
        if [ "$1" = key ] && [ "$2" = "$SCAN" ]; then echo "$3"; return 0; fi
    done < "$_f"
    return 1
}

# make_patched SRC DST : exchange labels on lines for $SA and $SB
make_patched() {
    local _src="$1" _dst="$2" _line _w1 _w2 _w3 _new
    : > "$_dst" || return 1
    while IFS= read -r _line || [ -n "$_line" ]; do
        set -f
        set -- $_line
        set +f
        _new=""
        if [ "$1" = key ] && [ "$2" = "$SA" ] && [ "$3" = "$KA" ]; then
            _w2=$2; shift 3
            _new="key $_w2 $KB${*:+ $*}"
            echo "# hkmc.track-button-swap: was key $_w2 $KA" >> "$_dst"
        elif [ "$1" = key ] && [ "$2" = "$SB" ] && [ "$3" = "$KB" ]; then
            _w2=$2; shift 3
            _new="key $_w2 $KA${*:+ $*}"
            echo "# hkmc.track-button-swap: was key $_w2 $KB" >> "$_dst"
        fi
        if [ -n "$_new" ]; then
            echo "$_new" >> "$_dst"
        else
            echo "$_line" >> "$_dst"
        fi
    done < "$_src"
}

# ---------- who holds an input node open ----------
# echoes "pid:comm" for every process with $1 open
node_readers() {
    local _node="$1" _d _pid _comm _out=""
    for _d in /proc/[0-9]*; do
        _pid=${_d#/proc/}
        ls -l "$_d/fd" 2>/dev/null | grep -q -e "-> $_node\$" -e "-> $_node (deleted)\$" || continue
        _comm=""
        read _comm < "$_d/comm" 2>/dev/null
        _out="$_out $_pid:${_comm:-?}"
    done
    echo $_out
}

# readers other than system_server (and ourselves)
foreign_readers() {
    local _r _o=""
    for _r in $(node_readers "$1"); do
        case "$_r" in
            *:system_server|*:InputReader|*:getevent|$$:*) ;;
            *) _o="$_o $_r" ;;
        esac
    done
    echo $_o
}

# ---------- live keymap reload ----------
# Recreate /dev/input/eventN so EventHub sees DELETE + CREATE and reloads
# the .kl. The new node is fully prepared (owner/mode) under a temp name and
# hard-linked in, so EventHub never sees a half-permissioned node.
reload_node() {
    local _node="$1" _base _mm _maj _min _perm _own _grp _mode
    _base=${_node##*/}
    case "$_node" in "$INPUT_DIR"/event*) ;; *) log "reload: unexpected node $_node"; return 1 ;; esac
    if ! read _mm < "$SYSCLASS/$_base/dev" 2>/dev/null; then
        log "reload: no $SYSCLASS/$_base/dev"; return 1
    fi
    _maj=${_mm%%:*}; _min=${_mm#*:}
    set -f
    set -- $(ls -l "$_node" 2>/dev/null)
    set +f
    _perm=$1
    case "$2" in [0-9]*) _own=$3; _grp=$4 ;; *) _own=$2; _grp=$3 ;; esac
    case "$_perm" in c*) ;; *) log "reload: $_node is not a char device"; return 1 ;; esac
    case "$_perm" in
        crw-rw-rw-*) _mode=666 ;; crw-rw-r--*) _mode=664 ;; crw-rw----*) _mode=660 ;;
        crw-r-----*) _mode=640 ;; crw-------*) _mode=600 ;; *) _mode=660 ;;
    esac
    if [ "$(getenforce 2>/dev/null)" = Enforcing ] && ! have restorecon; then
        log "reload: SELinux enforcing and no restorecon; skipping (reboot to apply)"; return 1
    fi
    rm -f "$TMP_NODE" "$TMP_NODE.chk"
    mknod "$TMP_NODE" c "$_maj" "$_min" 2>/dev/null || { log "reload: mknod failed"; return 1; }
    chown "$_own:$_grp" "$TMP_NODE" 2>/dev/null || chown "$_own.$_grp" "$TMP_NODE" 2>/dev/null || {
        rm -f "$TMP_NODE"; log "reload: chown $_own:$_grp failed"; return 1; }
    chmod "$_mode" "$TMP_NODE"
    # make sure hard links work here before touching the real node
    ln "$TMP_NODE" "$TMP_NODE.chk" 2>/dev/null || { rm -f "$TMP_NODE"; log "reload: ln unsupported"; return 1; }
    rm -f "$TMP_NODE.chk"
    rm -f "$_node"
    sleep 1
    if ! ln "$TMP_NODE" "$_node" 2>/dev/null; then
        mv "$TMP_NODE" "$_node"
        log "reload: relink failed; node restored, REBOOT needed for keys on $_node"
        return 1
    fi
    rm -f "$TMP_NODE"
    [ "$(getenforce 2>/dev/null)" = Enforcing ] && restorecon "$_node" 2>/dev/null
    log "reload: reopened $_node ($_maj:$_min $_own:$_grp $_mode)"
    return 0
}

# reopen every node whose device uses keylayout $1
reload_for_kl() {
    local _kl="$1" _l _n _k _any=1
    [ "$(cfg reload 1)" = 1 ] || { log "reload=0: reboot to apply"; return 0; }
    list_devices
    while IFS= read -r _l || [ -n "$_l" ]; do
        _n=${_l%%"|"*}; _k=${_l#*"|"}; _k=${_k%%"|"*}
        [ "$_k" = "$_kl" ] || continue
        reload_node "$_n" && _any=0
    done < "$WORK/devices.txt"
    return $_any
}

# ---------- backup bookkeeping ----------
# $BACKUP_DIR/<flat>.orig        stock bytes
# $BACKUP_DIR/<flat>.path        live path
# $BACKUP_DIR/<flat>.orig.md5    md5 of stock
# $BACKUP_DIR/<flat>.patched.md5 md5 we wrote

bk() { echo "$BACKUP_DIR/$(flat "$1")"; }

write_live() {
    local _src="$1" _live="$2"
    case "$_live" in "$SYS_PREFIX"*) ;; *) log "FAIL: refusing to write outside $SYS_PREFIX: $_live"; return 1 ;; esac
    sys_rw || { log "FAIL: remount /system rw"; return 1; }
    if ! cp "$_src" "$_live.hkmc.track-button-swap.tmp"; then rm -f "$_live.hkmc.track-button-swap.tmp"; sys_ro; log "FAIL: copy to $_live.hkmc.track-button-swap.tmp"; return 1; fi
    chmod 644 "$_live.hkmc.track-button-swap.tmp"
    chown 0:0 "$_live.hkmc.track-button-swap.tmp" 2>/dev/null || chown 0.0 "$_live.hkmc.track-button-swap.tmp" 2>/dev/null
    if ! mv "$_live.hkmc.track-button-swap.tmp" "$_live"; then rm -f "$_live.hkmc.track-button-swap.tmp"; sys_ro; log "FAIL: mv into $_live"; return 1; fi
    sync
    sys_ro
    return 0
}

# Put one backed-up file back. 0 = stock now live, 1 = left alone.
restore_one() {
    local _b="$1" _live _orig _pat _cur
    read _live < "$_b.path" 2>/dev/null || return 1
    read _orig < "$_b.orig.md5" 2>/dev/null
    read _pat < "$_b.patched.md5" 2>/dev/null
    _cur=$(file_md5 "$_live")
    if [ "$_cur" = "$_orig" ]; then
        log "restore: $_live already stock"
        return 0
    fi
    if [ -n "$_pat" ] && [ "$_cur" = "$_pat" ]; then
        write_live "$_b.orig" "$_live" || return 1
        if [ "$(file_md5 "$_live")" = "$_orig" ]; then
            log "restore: $_live back to stock"
            reload_for_kl "$_live"
            return 0
        fi
        log "FAIL: restore of $_live did not verify"
        return 1
    fi
    log "restore: $_live changed by something else (md5 $_cur); leaving it and keeping backup"
    return 1
}

drop_backup() {
    rm -f "$1.orig" "$1.path" "$1.orig.md5" "$1.patched.md5"
}

# restore every backup except the one for live path $1 (may be empty)
restore_others() {
    local _keep="$1" _p _b
    for _p in "$BACKUP_DIR"/*.path; do
        [ -f "$_p" ] || continue
        _b=${_p%.path}
        if [ -n "$_keep" ] && [ "$_b" = "$(bk "$_keep")" ]; then continue; fi
        restore_one "$_b" && drop_backup "$_b"
    done
}

restore_all() {
    local _p _b _rc=0
    for _p in "$BACKUP_DIR"/*.path; do
        [ -f "$_p" ] || continue
        _b=${_p%.path}
        if restore_one "$_b"; then drop_backup "$_b"; else _rc=1; fi
    done
    rm -f "$STATE_DIR/.applied"
    return $_rc
}

# ---------- detection + apply ----------

# For a keylayout, compute SA/SB against the STOCK copy (backup if we have one).
# Returns 0 and sets SA SB SRC when the pair is unambiguous.
resolve_pair() {
    local _kl="$1" _b _sa _sb
    _b=$(bk "$_kl")
    if [ -f "$_b.orig" ]; then SRC="$_b.orig"; else SRC="$_kl"; fi
    [ -r "$SRC" ] || return 1
    _sa=$(cfg scan_a 34); _sb=$(cfg scan_b 35)
    if [ "$_sa" = auto ]; then
        LAB=$KA; _sa=$(scans_for "$SRC")
        [ "$(count_words "$_sa")" = 1 ] || { WHY="$_kl: $KA on scancodes [${_sa:-none}]"; return 1; }
    else
        SCAN=$_sa; [ "$(label_of "$SRC")" = "$KA" ] || { WHY="$_kl: scan_a $_sa is not $KA"; return 1; }
    fi
    if [ "$_sb" = auto ]; then
        LAB=$KB; _sb=$(scans_for "$SRC")
        [ "$(count_words "$_sb")" = 1 ] || { WHY="$_kl: $KB on scancodes [${_sb:-none}]"; return 1; }
    else
        SCAN=$_sb; [ "$(label_of "$SRC")" = "$KB" ] || { WHY="$_kl: scan_b $_sb is not $KB"; return 1; }
    fi
    SA=$_sa; SB=$_sb
    return 0
}

# A backup whose live file is now neither stock nor our patch is stale
# (firmware update, or another mod rewrote the file). Retire it so the
# current live file becomes the new stock snapshot.
retire_stale() {
    local _p _b _live _o _q _c
    for _p in "$BACKUP_DIR"/*.path; do
        [ -f "$_p" ] || continue
        _b=${_p%.path}
        read _live < "$_p"
        read _o < "$_b.orig.md5" 2>/dev/null
        _q=""; read _q < "$_b.patched.md5" 2>/dev/null
        _c=$(file_md5 "$_live") || continue
        [ "$_c" = "$_o" ] && continue
        [ -n "$_q" ] && [ "$_c" = "$_q" ] && continue
        mkdir -p "$BACKUP_DIR/stale"
        mv "$_b.orig" "$BACKUP_DIR/stale/${_b##*/}.orig.$(date +%s 2>/dev/null)" 2>/dev/null
        drop_backup "$_b"
        rm -f "$STATE_DIR/.applied"
        log "stale backup retired: $_live changed outside this package (md5 $_c); re-snapshotting"
    done
}

do_apply() {
    local _want _l _k _seen=" " _cands="" _n _b _cur _pat _orig _r
    KA=$(cfg key_a CHANNEL_UP); KB=$(cfg key_b CHANNEL_DOWN)
    retire_stale
    _want=$(cfg kl_file auto)
    list_devices
    if [ ! -s "$WORK/devices.txt" ]; then
        log "FAIL: dumpsys input listed no devices with a keylayout"
        return 1
    fi
    # candidate keylayouts (unique), each resolved against stock bytes
    while IFS= read -r _l || [ -n "$_l" ]; do
        _k=${_l#*"|"}; _k=${_k%%"|"*}
        case "$_seen" in *" $_k "*) continue ;; esac
        _seen="$_seen$_k "
        [ "$_want" = auto ] || [ "$_want" = "$_k" ] || continue
        WHY=""
        if resolve_pair "$_k"; then
            _cands="$_cands $_k"
            log "candidate: $_k  $KA=scan $SA  $KB=scan $SB"
        else
            # only noisy when the file mentions the keys at all
            case "$WHY" in *"[none]"*) ;; "") ;; *) log "skip: $WHY" ;; esac
        fi
    done < "$WORK/devices.txt"

    # A device-specific keylayout beats the shared Generic.kl fallback.
    if [ "$(count_words "$_cands")" -gt 1 ]; then
        _l=""
        for _k in $_cands; do
            case "$_k" in */Generic.kl) ;; *) _l="$_l $_k" ;; esac
        done
        [ -n "$_l" ] && _cands=$_l
    fi
    _n=$(count_words "$_cands")
    if [ "$_n" != 1 ]; then
        if [ "$_n" = 0 ]; then
            log "FAIL: no live keylayout maps exactly one scancode each to $KA and $KB"
        else
            log "FAIL: ambiguous, several keylayouts qualify:$_cands  (set kl_file)"
        fi
        log "      run the probe (Manager > Packages > Launch) and check the report"
        return 1
    fi
    KL=${_cands# }
    case "$KL" in */Generic.kl) log "note: target is Generic.kl; any other device using it gets the same swap" ;; esac
    resolve_pair "$KL" || return 1

    # double-fire guard: anyone besides system_server reading the raw node
    # would still see the stock scancode and could act on it.
    if [ "$(cfg force 0)" != 1 ]; then
        while IFS= read -r _l || [ -n "$_l" ]; do
            _k=${_l#*"|"}; _k=${_k%%"|"*}
            [ "$_k" = "$KL" ] || continue
            _r=$(foreign_readers "${_l%%"|"*}")
            if [ -n "$_r" ]; then
                log "FAIL: ${_l%%"|"*} is also read directly by: $_r"
                log "      those would still see the stock key (possible double action). Not applying."
                log "      Review with the probe; set force=1 only if those processes ignore seek keys."
                return 1
            fi
        done < "$WORK/devices.txt"
    fi

    restore_others "$KL"

    _b=$(bk "$KL")
    mkdir -p "$BACKUP_DIR"
    if [ ! -f "$_b.orig" ]; then
        cp "$KL" "$_b.orig" || { log "FAIL: backup $KL"; return 1; }
        echo "$KL" > "$_b.path"
        file_md5 "$_b.orig" > "$_b.orig.md5"
        [ "$(file_md5 "$_b.orig")" = "$(file_md5 "$KL")" ] || { log "FAIL: backup verify"; drop_backup "$_b"; return 1; }
        log "backup: $KL -> $_b.orig"
        SRC="$_b.orig"
    fi
    read _orig < "$_b.orig.md5"

    make_patched "$_b.orig" "$WORK/patched.kl" || { log "FAIL: build patched kl"; return 1; }
    # verify: exactly our two lines flipped
    # (other scancodes may legitimately share these labels, e.g. 97/98)
    SCAN=$SA; [ "$(label_of "$WORK/patched.kl")" = "$KB" ] || { log "FAIL: verify scan $SA"; return 1; }
    SCAN=$SB; [ "$(label_of "$WORK/patched.kl")" = "$KA" ] || { log "FAIL: verify scan $SB"; return 1; }
    LAB=$KA; _r=$(count_words "$(scans_for "$_b.orig")")
    [ "$(count_words "$(scans_for "$WORK/patched.kl")")" = "$_r" ] || { log "FAIL: verify $KA count"; return 1; }
    LAB=$KB; _r=$(count_words "$(scans_for "$_b.orig")")
    [ "$(count_words "$(scans_for "$WORK/patched.kl")")" = "$_r" ] || { log "FAIL: verify $KB count"; return 1; }
    [ $(grep -c '' "$WORK/patched.kl") = $(( $(grep -c '' "$_b.orig") + 2 )) ] || { log "FAIL: verify line count"; return 1; }
    _pat=$(file_md5 "$WORK/patched.kl")

    _cur=$(file_md5 "$KL")
    if [ "$_cur" = "$_pat" ]; then
        log "already applied: $KL"
    else
        if [ "$_cur" != "$_orig" ]; then
            read _r < "$_b.patched.md5" 2>/dev/null
            if [ "$_cur" != "$_r" ]; then
                log "FAIL: $KL is neither stock nor our patch (md5 $_cur); not touching it"
                return 1
            fi
        fi
        echo "$_pat" > "$_b.patched.md5"
        write_live "$WORK/patched.kl" "$KL" || return 1
        [ "$(file_md5 "$KL")" = "$_pat" ] || { log "FAIL: write verify $KL"; return 1; }
        log "applied: $KL  scan $SA -> $KB, scan $SB -> $KA"
    fi
    echo "$_pat" > "$_b.patched.md5"
    {
        echo "kl=$KL"
        echo "scan_a=$SA was=$KA now=$KB"
        echo "scan_b=$SB was=$KB now=$KA"
    } > "$STATE_DIR/.applied"
    return 0
}
