#!/system/bin/sh
# Seed config. The swap service starts right after this hook and does the work.
. ./scripts/common.sh
seed_config
log "postinstall: config in $STATE_DIR; swap service will apply"
exit 0
