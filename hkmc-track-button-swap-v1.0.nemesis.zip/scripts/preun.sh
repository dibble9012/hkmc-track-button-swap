#!/system/bin/sh
# Put the stock keylayout back (only if the live file is still our patch),
# reopen the input node so stock behaviour returns without a reboot.
. ./scripts/common.sh
log "preuninstall: restoring stock keylayout"
if restore_all; then
    rmdir "$BACKUP_DIR" 2>/dev/null
    log "preuninstall: stock mapping restored"
else
    log "preuninstall: something was left alone; backup kept in $BACKUP_DIR"
fi
rm -rf "$WORK"
exit 0
