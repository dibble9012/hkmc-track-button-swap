#!/system/bin/sh
# Refuse to install alongside an earlier build under a different id (same
# keylayout; they would fight over it and undo the swap). Uninstall it first.
for OLD in local.hkmc.swrc-swap track_buttons_swap; do
    if [ -d "/data/nemesis/apps/$OLD" ]; then
        echo "hkmc.track-button-swap: old package $OLD is installed. Uninstall it first:"
        echo "  nemesis uninstall $OLD"
        mkdir -p /data/nemesis/logs/hkmc.track-button-swap 2>/dev/null
        echo "$(date) preinstall refused: $OLD still installed" >> /data/nemesis/logs/hkmc.track-button-swap/apply.log 2>/dev/null
        exit 1
    fi
done
exit 0
